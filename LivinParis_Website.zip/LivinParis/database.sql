-- Suppression et création de la base de données
DROP DATABASE IF EXISTS food_delivery;
CREATE DATABASE food_delivery;
USE food_delivery;

-- Création de la table utilisateur
DROP TABLE IF EXISTS Trajet;
DROP TABLE IF EXISTS utilisateur;
CREATE TABLE utilisateur (
    Num_util VARCHAR(50) NOT NULL,
    Nom VARCHAR(50) NOT NULL,
    Prenom VARCHAR(50) NOT NULL,
    Rue VARCHAR(50) NOT NULL,
    Numero_Rue INT NOT NULL,
    CodePostal VARCHAR(50) NOT NULL,
    Ville VARCHAR(50) NOT NULL,
    Tel VARCHAR(50) NOT NULL,
    Email VARCHAR(50) NOT NULL UNIQUE,
    Mot_de_passe VARCHAR(255) NOT NULL,
    Role TINYINT,
    plat_de_jour VARCHAR(100) DEFAULT NULL,
    listes_clients VARCHAR(100) DEFAULT NULL,
    liste_plats VARCHAR(100) DEFAULT NULL,
    PRIMARY KEY (Num_util)
);

-- Création de la table Trajet
DROP TABLE IF EXISTS Trajet;
CREATE TABLE Trajet (
    id_trajet VARCHAR(50) NOT NULL,
    adresse_depart VARCHAR(100),
    adresse_arrivee VARCHAR(100),
    temps_estime TIME,
    Num_traj VARCHAR(50) NOT NULL,
    PRIMARY KEY (id_trajet),
    FOREIGN KEY (Num_traj) REFERENCES utilisateur(Num_util)
);

DELIMITER $$
CREATE TRIGGER verif_role_trajet
BEFORE INSERT ON Trajet
FOR EACH ROW
BEGIN
  IF (SELECT Role FROM utilisateur WHERE Num_util = NEW.Num_traj) NOT IN (1, 2) THEN
    SIGNAL SQLSTATE '45000'
    SET MESSAGE_TEXT = 'Seuls les rôles 1 ou 2 peuvent être associés à un trajet.';
  END IF;
END$$
DELIMITER ;

-- Création de la table Recette
DROP TABLE IF EXISTS Recette;
CREATE TABLE Recette (
    id_recette VARCHAR(50) NOT NULL,
    nom_recette VARCHAR(100),
    description TEXT,
    ingredients TEXT,
    instructions TEXT,
    PRIMARY KEY (id_recette)
);

-- Création de la table Ingrédients
DROP TABLE IF EXISTS ingrédients;
CREATE TABLE ingrédients (
    Nom VARCHAR(50) NOT NULL,
    PRIMARY KEY (Nom)
);

-- Création de la table Livraison
DROP TABLE IF EXISTS Livraison;
CREATE TABLE Livraison (
    id_livraison VARCHAR(50) NOT NULL,
    date_livraison DATE,
    heure TIME,
    statut VARCHAR(50),
    id_trajet VARCHAR(50) NOT NULL,
    PRIMARY KEY (id_livraison),
    FOREIGN KEY (id_trajet) REFERENCES Trajet(id_trajet)
);

-- Création de la table Plat
DROP TABLE IF EXISTS Plat;
CREATE TABLE Plat (
    id_plat VARCHAR(50) NOT NULL,
    Nom_Plat VARCHAR(100),
    type VARCHAR(50),
    date_fabrication DATE,
    date_peremption DATE,
    regime VARCHAR(50),
    Nature VARCHAR(50),
    Num_cuisinier VARCHAR(50) NOT NULL,
    Prix DECIMAL(15,3) NOT NULL DEFAULT 0,
    PRIMARY KEY (id_plat),
    FOREIGN KEY (Num_cuisinier) REFERENCES utilisateur(Num_util)
);

-- Création de la table Commande
DROP TABLE IF EXISTS Commande;
CREATE TABLE Commande (
    Numero_Commande VARCHAR(50) NOT NULL,
    id_plat VARCHAR(50),
    Prix DECIMAL(15,3),
    Quantite INT,
    date_commande DATE,
    Num_client VARCHAR(50) NOT NULL,
    PRIMARY KEY (Numero_Commande),
    FOREIGN KEY (Num_client) REFERENCES utilisateur(Num_util),
    FOREIGN KEY (id_plat) REFERENCES Plat(id_plat)
);

-- Création de la table Avis
DROP TABLE IF EXISTS Avis;
CREATE TABLE Avis (
    id_avis VARCHAR(50) NOT NULL,
    note INT,
    commentaire TEXT,
    date_avis DATE,
    id_plat VARCHAR(50) NOT NULL,
    Num_client_avis VARCHAR(50) NOT NULL,
    PRIMARY KEY (id_avis),
    FOREIGN KEY (id_plat) REFERENCES Plat(id_plat),
    FOREIGN KEY (Num_client_avis) REFERENCES utilisateur(Num_util)
);

-- Création de la table Contient
DROP TABLE IF EXISTS contient;
CREATE TABLE contient (
    id_plat VARCHAR(50) NOT NULL,
    Nom VARCHAR(50) NOT NULL,
    volume VARCHAR(50),
    PRIMARY KEY (id_plat, Nom),
    FOREIGN KEY (id_plat) REFERENCES Plat(id_plat),
    FOREIGN KEY (Nom) REFERENCES ingrédients(Nom)
);
DELIMITER $$

CREATE TRIGGER verif_commande_non_self
BEFORE INSERT ON Commande
FOR EACH ROW
BEGIN
  DECLARE cuisinier_id VARCHAR(50);
  SELECT Num_cuisinier INTO cuisinier_id FROM Plat WHERE id_plat = NEW.id_plat;
  
  IF NEW.Num_client = cuisinier_id THEN
    SIGNAL SQLSTATE '45000'
    SET MESSAGE_TEXT = 'Un utilisateur ne peut pas commander son propre plat.';
  END IF;
END$$

DELIMITER ;

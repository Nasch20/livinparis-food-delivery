USE food_delivery;

-- Peuplement de la table utilisateur
INSERT INTO utilisateur (Num_util, Nom, Prenom, Rue, Numero_Rue, CodePostal, Ville, Tel, Email, Mot_de_passe, Role)
VALUES
('U001', 'Dupont', 'Jean', 'Rue de Paris', 10, '75001', 'Paris', '0600000001', 'jean.dupont@email.com', 'azerty', 0),
('U002', 'Martin', 'Claire', 'Avenue Victor Hugo', 22, '75016', 'Paris', '0600000002', 'claire.martin@email.com', 'azerty', 1),
('U003', 'Durand', 'Paul', 'Boulevard Voltaire', 5, '75011', 'Paris', '0600000003', 'paul.durand@email.com', 'azerty', 2),
('U004', 'Petit', 'Sophie', 'Rue de Lyon', 15, '75012', 'Paris', '0600000004', 'sophie.petit@email.com', 'azerty', 3);

-- Peuplement de la table Plat
INSERT INTO Plat (id_plat, Nom_Plat, type, date_fabrication, date_peremption, regime, Nature, Num_cuisinier, Prix)
VALUES
('P001', 'Raclette', 'Plat', '2025-01-10', '2025-01-15', 'Non végétarien', 'Française', 'U002', 12.50),
('P002', 'Salade de fruits', 'Dessert', '2025-01-11', '2025-01-13', 'Végétarien', 'Indifférent', 'U002', 7.00);

-- Peuplement de la table Commande
INSERT INTO Commande (Numero_Commande, id_plat, Prix, Quantite, date_commande, Num_client)
VALUES
('C001', 'P001', 12.50, 2, '2025-01-12', 'U001'),
('C002', 'P002', 7.00, 1, '2025-01-13', 'U003');

-- Peuplement de la table Avis
INSERT INTO Avis (id_avis, note, commentaire, date_avis, id_plat, Num_client_avis)
VALUES
('A001', 5, 'Excellent plat !', '2025-01-13', 'P001', 'U001'),
('A002', 4, 'Très bon dessert.', '2025-01-14', 'P002', 'U003');

-- Peuplement de la table ingrédients
INSERT INTO ingrédients (Nom)
VALUES
('fromage'),
('pomme de terre'),
('laitue'),
('fraise');

-- Peuplement de la table contient
INSERT INTO contient (id_plat, Nom, volume)
VALUES
('P001', 'fromage', '200g'),
('P001', 'pomme de terre', '150g'),
('P002', 'laitue', '50g'),
('P002', 'fraise', '30g');

-- Peuplement de la table Trajet
INSERT INTO Trajet (id_trajet, adresse_depart, adresse_arrivee, temps_estime, Num_traj)
VALUES
('T001', 'Rue de Paris, 75001 Paris', 'Avenue Victor Hugo, 75016 Paris', '00:30:00', 'U002');

-- Peuplement de la table Livraison
INSERT INTO Livraison (id_livraison, date_livraison, heure, statut, id_trajet)
VALUES
('L001', '2025-01-12', '12:00:00', 'Livrée', 'T001');

-- Peuplement de la table Recette
INSERT INTO Recette (id_recette, nom_recette, description, ingredients, instructions)
VALUES
('R001', 'Raclette', 'Plat savoyard à base de fromage fondu.', 'fromage, pomme de terre', 'Faire fondre le fromage et servir avec des pommes de terre.'); 
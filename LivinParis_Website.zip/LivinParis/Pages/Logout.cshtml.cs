using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace LivinParis.Pages
{
    /// <summary>
    /// Gèrer la logique de déconnexion
    /// </summary>
    public class LogoutModel : PageModel
    {
        /// <summary>
        /// Traiter la déconnexion de l'utilisateur
        /// </summary>
        public IActionResult OnPost()
        {
            // Supprimer toutes les variables de session
            HttpContext.Session.Clear();
            
            // Rediriger vers la page d'accueil
            return RedirectToPage("/Index");
        }

        /// <summary>
        /// Rediriger vers la page d'accueil si accès direct
        /// </summary>
        public IActionResult OnGet()
        {
            // Si quelqu'un accède directement à la page de déconnexion via GET,
            // on le redirige vers la page d'accueil
            return RedirectToPage("/Index");
        }
    }
} 
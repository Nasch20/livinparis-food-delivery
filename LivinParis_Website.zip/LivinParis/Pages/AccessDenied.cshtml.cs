using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace LivinParis.Pages
{
    public class AccessDeniedModel : PageModel
    {
        public void OnGet()
        {
        }
    }
} 
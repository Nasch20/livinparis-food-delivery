using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using LivinParis.Data;
using LivinParis.Models;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;

namespace LivinParis.Pages
{
    /// <summary>
    /// Gère la logique de la page de connexion
    /// </summary>
    public class LoginModel : PageModel
    {
        private readonly ApplicationDbContext _context;

        /// <summary>
        /// Initialise une nouvelle instance du modèle de connexion
        /// </summary>
        public LoginModel(ApplicationDbContext context)
        {
            _context = context;
        }

        [BindProperty]
        public string Email { get; set; }

        [BindProperty]
        public string Password { get; set; }

        public string ErrorMessage { get; set; }

        /// <summary>
        /// Gère l'affichage initial de la page de connexion
        /// </summary>
        public void OnGet()
        {
        }

        /// <summary>
        /// Traite la soumission du formulaire de connexion
        /// </summary>
        public async Task<IActionResult> OnPostAsync()
        {
            if (string.IsNullOrEmpty(Email) || string.IsNullOrEmpty(Password))
            {
                ErrorMessage = "Veuillez remplir tous les champs";
                return Page();
            }

            // Vérification des identifiants d'administration
            if (Email == "esilv@edu.devinci.fr" && Password == "esilv2025")
            {
                var claims = new List<Claim>
                {
                    new Claim(ClaimTypes.Name, "Administrateur"),
                    new Claim(ClaimTypes.Email, Email),
                    new Claim(ClaimTypes.Role, "3") // Role = 3 pour administrateur
                };

                var claimsIdentity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
                var authProperties = new AuthenticationProperties();

                await HttpContext.SignInAsync(
                    CookieAuthenticationDefaults.AuthenticationScheme,
                    new ClaimsPrincipal(claimsIdentity),
                    authProperties);

                return RedirectToPage("/Admin/Index");
            }

            // Vérification des identifiants dans la base de données (remplacement du FirstOrDefaultAsync par une boucle)
            var utilisateurs = await _context.utilisateur.ToListAsync();
            LivinParis.Models.Utilisateur utilisateur = null;
            foreach (var u in utilisateurs)
            {
                if (u.Email == Email && u.Mot_de_passe == Password)
                {
                    utilisateur = u;
                    break;
                }
            }

            if (utilisateur == null)
            {
                ErrorMessage = "Email ou mot de passe incorrect";
                return Page();
            }

            var userClaims = new List<Claim>
            {
                new Claim(ClaimTypes.Name, utilisateur.Nom + " " + utilisateur.Prenom),
                new Claim(ClaimTypes.Email, utilisateur.Email),
                new Claim(ClaimTypes.Role, utilisateur.Role.ToString())
            };

            var userClaimsIdentity = new ClaimsIdentity(userClaims, CookieAuthenticationDefaults.AuthenticationScheme);
            var userAuthProperties = new AuthenticationProperties();

            await HttpContext.SignInAsync(
                CookieAuthenticationDefaults.AuthenticationScheme,
                new ClaimsPrincipal(userClaimsIdentity),
                userAuthProperties);

            return RedirectToPage("/Index");
        }
    }
} 
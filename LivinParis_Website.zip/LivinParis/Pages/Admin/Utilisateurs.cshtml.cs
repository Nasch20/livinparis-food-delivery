using Microsoft.AspNetCore.Mvc.RazorPages;
using LivinParis.Data;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using MySql.Data.MySqlClient;
using Microsoft.Extensions.Configuration;

namespace LivinParis.Pages.Admin
{
    public class UtilisateursModel : PageModel
    {
        private readonly string _connectionString;

        public UtilisateursModel(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection");
        }

        public List<UtilisateurInfo> Utilisateurs { get; set; } = new();

        public class UtilisateurInfo
        {
            public string Nom { get; set; }
            public string Prenom { get; set; }
            public string Email { get; set; }
            public string Role { get; set; }
        }

        public async Task OnGetAsync()
        {
            Utilisateurs = new List<UtilisateurInfo>();
            using (var connection = new MySqlConnection(_connectionString))
            {
                await connection.OpenAsync();
                using (var cmd = new MySqlCommand("SELECT Nom, Prenom, Email, Role FROM utilisateur", connection))
                using (var reader = await cmd.ExecuteReaderAsync())
                {
                    while (await reader.ReadAsync())
                    {
                        Utilisateurs.Add(new UtilisateurInfo
                        {
                            Nom = reader.GetString(0),
                            Prenom = reader.GetString(1),
                            Email = reader.GetString(2),
                            Role = reader.GetInt32(3) == 0 ? "Client" :
                                   reader.GetInt32(3) == 1 ? "Cuisinier" :
                                   reader.GetInt32(3) == 2 ? "Client&Cuisinier" : "Administrateur"
                        });
                    }
                }
            }
        }
    }
} 
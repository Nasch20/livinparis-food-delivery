using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using LivinParis.Data;
using LivinParis.Models;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading.Tasks;
using System.Globalization;
using Microsoft.AspNetCore.Authorization;
using MySql.Data.MySqlClient;
using Microsoft.Extensions.Configuration;

namespace LivinParis.Pages.Admin
{
    [Authorize(Policy = "AdminOnly")]
    public class IndexModel : PageModel
    {
        private readonly ApplicationDbContext _context;
        private readonly string _connectionString;

        public IndexModel(ApplicationDbContext context, IConfiguration configuration)
        {
            _context = context;
            _connectionString = configuration.GetConnectionString("DefaultConnection");
        }

        public int UtilisateurCount { get; set; }
        public decimal SommeCommandes { get; set; }
        public int PlatsCeMois { get; set; }
        public List<UtilisateurInfo> Utilisateurs { get; set; }

        public class UtilisateurInfo
        {
            public string Num_util { get; set; }
            public string Nom { get; set; }
            public string Prenom { get; set; }
            public string Email { get; set; }
            public string Role { get; set; }
        }

        public async Task<IActionResult> OnGetAsync()
        {
            Utilisateurs = new List<UtilisateurInfo>();
            using (var connection = new MySqlConnection(_connectionString))
            {
                await connection.OpenAsync();
                // Nombre total d'utilisateurs
                using (var cmd = new MySqlCommand("SELECT COUNT(*) FROM utilisateur", connection))
                {
                    UtilisateurCount = Convert.ToInt32(await cmd.ExecuteScalarAsync());
                }
                // Somme totale des commandes passées
                using (var cmd = new MySqlCommand("SELECT IFNULL(SUM(Prix * Quantite),0) FROM Commande", connection))
                {
                    SommeCommandes = Convert.ToDecimal(await cmd.ExecuteScalarAsync());
                }
                // Nombre de plats créés ce mois-ci
                var now = DateTime.Now;
                using (var cmd = new MySqlCommand("SELECT COUNT(*) FROM Plat WHERE MONTH(date_fabrication) = @mois AND YEAR(date_fabrication) = @annee", connection))
                {
                    cmd.Parameters.AddWithValue("@mois", now.Month);
                    cmd.Parameters.AddWithValue("@annee", now.Year);
                    PlatsCeMois = Convert.ToInt32(await cmd.ExecuteScalarAsync());
                }
                // Liste des utilisateurs
                using (var cmd = new MySqlCommand("SELECT Num_util, Nom, Prenom, Email, Role FROM utilisateur", connection))
                using (var reader = await cmd.ExecuteReaderAsync())
                {
                    while (await reader.ReadAsync())
                    {
                        Utilisateurs.Add(new UtilisateurInfo
                        {
                            Num_util = reader.GetString(0),
                            Nom = reader.GetString(1),
                            Prenom = reader.GetString(2),
                            Email = reader.GetString(3),
                            Role = reader.GetInt32(4) == 0 ? "Client" :
                                   reader.GetInt32(4) == 1 ? "Cuisinier" :
                                   reader.GetInt32(4) == 2 ? "Client&Cuisinier" : "Administrateur"
                        });
                    }
                }
            }
            return Page();
        }

        public async Task<IActionResult> OnPostDeleteUserAsync(string num_util)
        {
            using (var connection = new MySqlConnection(_connectionString))
            {
                await connection.OpenAsync();
                using (var transaction = await connection.BeginTransactionAsync())
                {
                    try
                    {
                        // 1. Supprimer les avis écrits par cet utilisateur
                        using (var cmd = new MySqlCommand("DELETE FROM Avis WHERE Num_client_avis = @num_util", connection, (MySqlTransaction)transaction))
                        {
                            cmd.Parameters.AddWithValue("@num_util", num_util);
                            await cmd.ExecuteNonQueryAsync();
                        }
                        // 2. Trouver tous les plats créés par cet utilisateur
                        List<string> platIds = new List<string>();
                        using (var cmd = new MySqlCommand("SELECT id_plat FROM Plat WHERE Num_cuisinier = @num_util", connection, (MySqlTransaction)transaction))
                        {
                            cmd.Parameters.AddWithValue("@num_util", num_util);
                            using (var reader = await cmd.ExecuteReaderAsync())
                            {
                                while (await reader.ReadAsync())
                                {
                                    platIds.Add(reader.GetString(0));
                                }
                            }
                        }
                        if (platIds.Count > 0)
                        {
                            // 3. Supprimer tous les avis sur ces plats
                            using (var cmd = new MySqlCommand($"DELETE FROM Avis WHERE id_plat IN ({string.Join(",", platIds.Select((_,i)=>"@platId"+i))})", connection, (MySqlTransaction)transaction))
                            {
                                for (int i = 0; i < platIds.Count; i++)
                                    cmd.Parameters.AddWithValue("@platId"+i, platIds[i]);
                                await cmd.ExecuteNonQueryAsync();
                            }
                            // 4. Supprimer les commandes associées à ces plats
                            using (var cmd = new MySqlCommand($"DELETE FROM Commande WHERE id_plat IN ({string.Join(",", platIds.Select((_,i)=>"@platIdC"+i))})", connection, (MySqlTransaction)transaction))
                            {
                                for (int i = 0; i < platIds.Count; i++)
                                    cmd.Parameters.AddWithValue("@platIdC"+i, platIds[i]);
                                await cmd.ExecuteNonQueryAsync();
                            }
                            // 5. Supprimer les plats
                            using (var cmd = new MySqlCommand($"DELETE FROM Plat WHERE id_plat IN ({string.Join(",", platIds.Select((_,i)=>"@platIdP"+i))})", connection, (MySqlTransaction)transaction))
                            {
                                for (int i = 0; i < platIds.Count; i++)
                                    cmd.Parameters.AddWithValue("@platIdP"+i, platIds[i]);
                                await cmd.ExecuteNonQueryAsync();
                            }
                        }
                        // 6. Supprimer les commandes où l'utilisateur est client
                        using (var cmd = new MySqlCommand("DELETE FROM Commande WHERE Num_client = @num_util", connection, (MySqlTransaction)transaction))
                        {
                            cmd.Parameters.AddWithValue("@num_util", num_util);
                            await cmd.ExecuteNonQueryAsync();
                        }
                        // 7. Supprimer l'utilisateur
                        using (var cmd = new MySqlCommand("DELETE FROM utilisateur WHERE Num_util = @num_util", connection, (MySqlTransaction)transaction))
                        {
                            cmd.Parameters.AddWithValue("@num_util", num_util);
                            await cmd.ExecuteNonQueryAsync();
                        }
                        await transaction.CommitAsync();
                    }
                    catch
                    {
                        await transaction.RollbackAsync();
                        throw;
                    }
                }
            }
            return RedirectToPage();
        }
    }
} 
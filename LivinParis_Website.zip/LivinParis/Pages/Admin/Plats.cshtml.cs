using Microsoft.AspNetCore.Mvc.RazorPages;
using LivinParis.Data;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Threading.Tasks;
using System;
using System.Linq;
using MySql.Data.MySqlClient;
using Microsoft.Extensions.Configuration;

namespace LivinParis.Pages.Admin
{
    public class PlatsModel : PageModel
    {
        private readonly string _connectionString;

        public PlatsModel(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection");
        }

        public List<PlatInfo> Plats { get; set; } = new();

        public class PlatInfo
        {
            public string Nom_Plat { get; set; }
            public string Type { get; set; }
            public DateTime DateFabrication { get; set; }
            public DateTime DatePeremption { get; set; }
            public string Regime { get; set; }
            public string Nature { get; set; }
            public string Cuisinier { get; set; }
        }

        /// <summary>
        /// Charge la liste des plats depuis la base de données en utilisant une requête SQL brute.
        /// </summary>
        public async Task OnGetAsync()
        {
            Plats = new List<PlatInfo>();
            using (var connection = new MySqlConnection(_connectionString))
            {
                await connection.OpenAsync();
                using (var cmd = new MySqlCommand("SELECT Nom_Plat, type, date_fabrication, date_peremption, regime, Nature, Num_cuisinier FROM Plat", connection))
                using (var reader = await cmd.ExecuteReaderAsync())
                {
                    while (await reader.ReadAsync())
                    {
                        var plat = new PlatInfo
                        {
                            Nom_Plat = reader.GetString(0),
                            Type = reader.GetString(1),
                            DateFabrication = reader.GetDateTime(2),
                            DatePeremption = reader.GetDateTime(3),
                            Regime = reader.GetString(4),
                            Nature = reader.GetString(5),
                            Cuisinier = reader.GetString(6)
                        };
                        Plats.Add(plat);
                    }
                }
            }
        }
    }
} 
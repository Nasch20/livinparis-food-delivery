using Microsoft.AspNetCore.Mvc.RazorPages;
using LivinParis.Data;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Threading.Tasks;
using System;
using System.Linq;
using MySql.Data.MySqlClient;
using Microsoft.Extensions.Configuration;

namespace LivinParis.Pages.Admin
{
    public class CommandesModel : PageModel
    {
        private readonly string _connectionString;

        public CommandesModel(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("DefaultConnection");
        }

        public List<CommandeInfo> Commandes { get; set; } = new();

        public class CommandeInfo
        {
            public string Numero_Commande { get; set; }
            public string Client { get; set; }
            public string Plat { get; set; }
            public decimal Prix { get; set; }
            public int Quantite { get; set; }
            public DateTime DateCommande { get; set; }
        }

        /// <summary>
        /// Charge la liste des commandes depuis la base de données en utilisant une requête SQL brute.
        /// </summary>
        public async Task OnGetAsync()
        {
            Commandes = new List<CommandeInfo>();
            using (var connection = new MySqlConnection(_connectionString))
            {
                await connection.OpenAsync();
                string query = @"SELECT c.Numero_Commande, u.Nom, u.Prenom, p.Nom_Plat, c.Prix, c.Quantite, c.date_commande
                                 FROM Commande c
                                 JOIN utilisateur u ON c.Num_client = u.Num_util
                                 JOIN Plat p ON c.id_plat = p.id_plat";
                using (var cmd = new MySqlCommand(query, connection))
                using (var reader = await cmd.ExecuteReaderAsync())
                {
                    while (await reader.ReadAsync())
                    {
                        var commande = new CommandeInfo
                        {
                            Numero_Commande = reader.GetString(0),
                            Client = reader.GetString(1) + " " + reader.GetString(2),
                            Plat = reader.GetString(3),
                            Prix = reader.GetDecimal(4),
                            Quantite = reader.GetInt32(5),
                            DateCommande = reader.GetDateTime(6)
                        };
                        Commandes.Add(commande);
                    }
                }
            }
        }
    }
} 
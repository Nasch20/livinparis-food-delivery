using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using LivinParis.Data;
using LivinParis.Models;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;

namespace LivinParis.Pages
{
    /// <summary>
    /// Gèrer la logique de la page d'inscription
    /// </summary>
    public class SignupModel : PageModel
    {
        private readonly ApplicationDbContext _context;

        /// <summary>
        /// Initialiser une nouvelle instance du modèle d'inscription
        /// </summary>
        public SignupModel(ApplicationDbContext context)
        {
            _context = context;
            Input = new InputModel();
        }

        [BindProperty]
        public InputModel Input { get; set; }

        public class InputModel
        {
            [Required(ErrorMessage = "Le nom est requis")]
            public string Nom { get; set; } = string.Empty;

            [Required(ErrorMessage = "Le prénom est requis")]
            public string Prenom { get; set; } = string.Empty;

            [Required(ErrorMessage = "La rue est requise")]
            public string Rue { get; set; } = string.Empty;

            [Required(ErrorMessage = "Le numéro de rue est requis")]
            public int NumeroRue { get; set; }

            [Required(ErrorMessage = "Le code postal est requis")]
            [RegularExpression(@"^\d{5}$", ErrorMessage = "Le code postal doit contenir 5 chiffres")]
            public string CodePostal { get; set; } = string.Empty;

            [Required(ErrorMessage = "La ville est requise")]
            public string Ville { get; set; } = string.Empty;

            [Required(ErrorMessage = "Le téléphone est requis")]
            [Phone(ErrorMessage = "Numéro de téléphone invalide")]
            public string Telephone { get; set; } = string.Empty;

            [Required(ErrorMessage = "L'email est requis")]
            [EmailAddress(ErrorMessage = "Format d'email invalide")]
            public string Email { get; set; } = string.Empty;

            [Required(ErrorMessage = "Le mot de passe est requis")]
            [StringLength(100, ErrorMessage = "Le mot de passe doit faire au moins {2} caractères", MinimumLength = 6)]
            [DataType(DataType.Password)]
            public string MotDePasse { get; set; } = string.Empty;

            [Required(ErrorMessage = "La confirmation du mot de passe est requise")]
            [DataType(DataType.Password)]
            [Compare("MotDePasse", ErrorMessage = "Les mots de passe ne correspondent pas")]
            public string ConfirmerMotDePasse { get; set; } = string.Empty;

            [Required(ErrorMessage = "Le rôle est requis")]
            public int Role { get; set; }
        }

        private async Task<string> GenerateUserNumberAsync()
        {
            // Extraire les deux premières lettres du prénom
            string prenomPart = Input.Prenom.Length >= 2 ? Input.Prenom.Substring(0, 2) : Input.Prenom.PadRight(2, 'X');
            
            // Extraire les deux dernières lettres du nom
            string nomPart = Input.Nom.Length >= 2 ? Input.Nom.Substring(Input.Nom.Length - 2) : Input.Nom.PadRight(2, 'X');
            
            // Créer le numéro d'utilisateur
            string baseUserNumber = $"{Input.NumeroRue}{prenomPart.ToUpper()}{nomPart.ToUpper()}";
            
            // Vérifier si ce numéro existe déjà
            string finalUserNumber = baseUserNumber;
            int counter = 1;
            
            // Remplacement du AnyAsync par une boucle classique
            bool exists = true;
            while (exists)
            {
                exists = false;
                var utilisateurs = await _context.utilisateur.ToListAsync();
                foreach (var u in utilisateurs)
                {
                    if (u.Num_util == finalUserNumber)
                    {
                        exists = true;
                        break;
                    }
                }
                if (exists)
                {
                    finalUserNumber = $"{baseUserNumber}{counter}";
                    counter++;
                }
            }
            return finalUserNumber;
        }

        /// <summary>
        /// Gèrer l'affichage initial de la page d'inscription
        /// </summary>
        public void OnGet()
        {
        }

        /// <summary>
        /// Traiter la soumission du formulaire d'inscription
        /// </summary>
        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            // Vérifier si l'email existe déjà (remplacement du AnyAsync par une boucle)
            var utilisateurs = await _context.utilisateur.ToListAsync();
            bool emailExists = false;
            foreach (var u in utilisateurs)
            {
                if (u.Email == Input.Email)
                {
                    emailExists = true;
                    break;
                }
            }

            if (emailExists)
            {
                ModelState.AddModelError("Input.Email", "Cet email est déjà utilisé.");
                return Page();
            }

            // Générer un numéro d'utilisateur unique
            string numUtil = await GenerateUserNumberAsync();

            // Créer un nouvel utilisateur
            var utilisateur = new Utilisateur
            {
                Num_util = numUtil,
                Nom = Input.Nom,
                Prenom = Input.Prenom,
                Rue = Input.Rue,
                Numero_Rue = Input.NumeroRue,
                CodePostal = Input.CodePostal,
                Ville = Input.Ville,
                Tel = Input.Telephone,
                Email = Input.Email,
                Mot_de_passe = Input.MotDePasse,
                Role = (byte)Input.Role
            };

            _context.utilisateur.Add(utilisateur);
            await _context.SaveChangesAsync();

            return RedirectToPage("/Login");
        }
    }
} 
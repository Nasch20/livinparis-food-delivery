using System.ComponentModel.DataAnnotations;

namespace LivinParis.Models
{
    public class Avis
    {
        [Key]
        public string id_avis { get; set; }

        [Required]
        public int note { get; set; }

        public string commentaire { get; set; }

        [Required]
        public DateTime date_avis { get; set; }

        [Required]
        public string id_plat { get; set; }

        [Required]
        public string Num_client_avis { get; set; }

        // Navigation properties
        public Plat Plat { get; set; }
        public Utilisateur Client { get; set; }
    }
} 
using System.ComponentModel.DataAnnotations;

namespace LivinParis.Models
{
    public class Plat
    {
        [Key]
        public string id_plat { get; set; }

        [Required]
        public string Nom_Plat { get; set; }

        [Required]
        public string type { get; set; }

        [Required]
        public DateTime date_fabrication { get; set; }

        [Required]
        public DateTime date_peremption { get; set; }

        [Required]
        public string regime { get; set; }

        [Required]
        public string Nature { get; set; }

        [Required]
        public string Num_cuisinier { get; set; }

        public decimal Prix { get; set; }

        // Navigation property
        public Utilisateur Cuisinier { get; set; }
    }
} 
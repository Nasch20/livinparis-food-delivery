using System.ComponentModel.DataAnnotations;

namespace LivinParis.Models
{
    /// <summary>
    /// Représente un utilisateur dans le système avec ses informations personnelles et son rôle
    /// </summary>
    public class Utilisateur
    {
        [Key]
        public string Num_util { get; set; }

        [Required]
        public string Nom { get; set; }

        [Required]
        public string Prenom { get; set; }

        [Required]
        public string Rue { get; set; }

        [Required]
        public int Numero_Rue { get; set; }

        [Required]
        public string CodePostal { get; set; }

        [Required]
        public string Ville { get; set; }

        [Required]
        public string Tel { get; set; }

        [Required]
        [EmailAddress]
        public string Email { get; set; }

        [Required]
        public string Mot_de_passe { get; set; }

        [Required]
        public byte Role { get; set; } // 0: Client, 1: Cuisinier, 2: Livreur, 3: Administrateur

        public string? plat_de_jour { get; set; }
        public string? listes_clients { get; set; }
        public string? liste_plats { get; set; }
    }
} 
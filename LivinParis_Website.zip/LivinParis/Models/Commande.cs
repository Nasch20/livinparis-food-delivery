using System.ComponentModel.DataAnnotations;

namespace LivinParis.Models
{
    public class Commande
    {
        [Key]
        public string Numero_Commande { get; set; }

        [Required]
        public string id_plat { get; set; }

        [Required]
        public decimal Prix { get; set; }

        [Required]
        public int Quantite { get; set; }

        [Required]
        public DateTime date_commande { get; set; }

        [Required]
        public string Num_client { get; set; }

        // Navigation properties
        public Plat Plat { get; set; }
        public Utilisateur Client { get; set; }
    }
} 
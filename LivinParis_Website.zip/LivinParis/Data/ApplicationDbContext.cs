using Microsoft.EntityFrameworkCore;
using LivinParis.Models;

namespace LivinParis.Data
{
    /// <summary>
    /// Contexte de base de données pour l'application, gère la connexion avec MySQL
    /// </summary>
    public class ApplicationDbContext : DbContext
    {
        /// <summary>
        /// Initialise une nouvelle instance du contexte de base de données
        /// </summary>
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        /// <summary>
        /// Collection des utilisateurs dans la base de données
        /// </summary>
        public DbSet<Utilisateur> utilisateur { get; set; }

        /// <summary>
        /// Collection des plats dans la base de données
        /// </summary>
        public DbSet<Plat> plat { get; set; }

        /// <summary>
        /// Collection des commandes dans la base de données
        /// </summary>
        public DbSet<Commande> commande { get; set; }

        /// <summary>
        /// Collection des avis dans la base de données
        /// </summary>
        public DbSet<Avis> avis { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Configuration des relations
            modelBuilder.Entity<Plat>()
                .HasOne(p => p.Cuisinier)
                .WithMany()
                .HasForeignKey(p => p.Num_cuisinier);

            modelBuilder.Entity<Commande>()
                .HasOne(c => c.Plat)
                .WithMany()
                .HasForeignKey(c => c.id_plat);

            modelBuilder.Entity<Commande>()
                .HasOne(c => c.Client)
                .WithMany()
                .HasForeignKey(c => c.Num_client);

            modelBuilder.Entity<Avis>()
                .HasOne(a => a.Plat)
                .WithMany()
                .HasForeignKey(a => a.id_plat);

            modelBuilder.Entity<Avis>()
                .HasOne(a => a.Client)
                .WithMany()
                .HasForeignKey(a => a.Num_client_avis);
        }
    }
} 
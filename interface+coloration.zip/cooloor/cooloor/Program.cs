﻿using System;
using System.Collections.Generic;
using System.Linq;
using MySql.Data.MySqlClient;

namespace cooloor
{

    public class Utilisateur
    {
        public string Num_util { get; set; }
        public string Nom { get; set; }
        public string Prenom { get; set; }
        public string Rue { get; set; }
        public int Numero_Rue { get; set; }
        public string CodePostal { get; set; }
        public string Ville { get; set; }
        public string Tel { get; set; }
        public string Email { get; set; }
        public int Role { get; set; }
        public List<string> voisins { get; set; } = new List<string>();
        public Utilisateur(string nom, int num)
        {
            this.Nom = nom;
            this.Num_util = num.ToString();
            this.voisins = new List<string>();
        }
        public List<string> Voisins
        {
            get { return this.voisins; }
        }
        public Utilisateur() { }
    }


    public class Plat
    {
        public string Id_plat { get; set; }
        public string Nom_Plat { get; set; }
        public string Type { get; set; }
        public DateTime Date_fabrication { get; set; }
        public DateTime Date_peremption { get; set; }
        public string Regime { get; set; }
        public string Nature { get; set; }
        public decimal Prix { get; set; }
        public string Num_cuisinier { get; set; }
    }

    public class Commande
    {
        public string Numero_Commande { get; set; }
        public string Id_plat { get; set; }
        public string Num_client { get; set; }
        public DateTime Date_commande { get; set; }
        public Utilisateur Client { get; set; }
        public Utilisateur Cuisinier { get; set; }
    }

    class Program
    {

        static List<Utilisateur> ChargerUtilisateurs()
        {
            List<Utilisateur> utilisateurs = new List<Utilisateur>();

            using var con = new MySqlConnection(connexionString);
            try
            {
                con.Open();
                var cmd = new MySqlCommand("SELECT Num_util, Nom, Prenom, Rue, Numero_Rue, CodePostal, Ville, Tel, Email, Role FROM utilisateur", con);
                using var reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    Utilisateur u = new Utilisateur
                    {
                        Num_util = reader["Num_util"].ToString(),
                        Nom = reader["Nom"].ToString(),
                        Prenom = reader["Prenom"].ToString(),
                        Rue = reader["Rue"].ToString(),
                        Numero_Rue = Convert.ToInt32(reader["Numero_Rue"]),
                        CodePostal = reader["CodePostal"].ToString(),
                        Ville = reader["Ville"].ToString(),
                        Tel = reader["Tel"].ToString(),
                        Email = reader["Email"].ToString(),
                        Role = Convert.ToInt32(reader["Role"]),
                        voisins = new List<string>() // initialisé vide pour l’instant
                    };
                    utilisateurs.Add(u);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Erreur de chargement des utilisateurs : {ex.Message}");
            }

            return utilisateurs;
        }
        static List<Plat> ChargerPlats()
        {
            List<Plat> plats = new List<Plat>();

            using var con = new MySqlConnection(connexionString);
            try
            {
                con.Open();
                var cmd = new MySqlCommand(@"SELECT Id_plat, Nom_Plat, Type, Date_fabrication, Date_peremption, 
                                            Regime, Nature, Prix, Num_cuisinier 
                                     FROM plat", con);
                using var reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    Plat p = new Plat
                    {
                        Id_plat = reader["Id_plat"].ToString(),
                        Nom_Plat = reader["Nom_Plat"].ToString(),
                        Type = reader["Type"].ToString(),
                        Date_fabrication = Convert.ToDateTime(reader["Date_fabrication"]),
                        Date_peremption = Convert.ToDateTime(reader["Date_peremption"]),
                        Regime = reader["Regime"].ToString(),
                        Nature = reader["Nature"].ToString(),
                        Prix = Convert.ToDecimal(reader["Prix"]),
                        Num_cuisinier = reader["Num_cuisinier"].ToString()
                    };
                    plats.Add(p);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Erreur de chargement des plats : {ex.Message}");
            }

            return plats;
        }

        static List<Utilisateur> ChargerCommandes(List<Utilisateur> utilisateurs, List<Plat> plats)
        {
            List<Utilisateur> l = utilisateurs;
            using var con = new MySqlConnection(connexionString);
            try
            {
                con.Open();
                var cmd = new MySqlCommand("SELECT Numero_Commande, Id_plat, Num_client, Date_commande FROM commande", con);
                using var reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    string numClient = reader["Num_client"].ToString();
                    string idPlat = reader["Id_plat"].ToString();

                    Utilisateur client = Conver(numClient,utilisateurs);
                    Plat plat = plats.FirstOrDefault(p => p.Id_plat == idPlat);
                    Utilisateur cuisinier = Conver(plat.Num_cuisinier,utilisateurs);
                    Commande c = new Commande
                    {
                        Numero_Commande = reader["Numero_Commande"].ToString(),
                        Id_plat = idPlat,
                        Num_client = numClient,
                        Date_commande = Convert.ToDateTime(reader["Date_commande"]),
                        Client = client,
                        Cuisinier = cuisinier
                    };
                    l[Contain(client.Num_util, l)].Voisins.Add(cuisinier.Num_util);
                    l[Contain(cuisinier.Num_util, l)].Voisins.Add(client.Num_util);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Erreur de chargement des commandes : {ex.Message}");
            }

            return l;
        }

        static int Contain(string a, List<Utilisateur> l)
        {
            int test = -1;
            for (int i = 0; i < l.Count; i++)
            {
                if (l[i].Num_util == a)
                {
                    test = i;
                }
            }
            return test;
        }
        static Utilisateur Conver(string a, List<Utilisateur> l)
        {
            Utilisateur test = new Utilisateur("temp", 1);
            for (int i = 0; i < l.Count; i++)
            {
                if (l[i].Num_util == a)
                {
                    test = l[i];
                }
            }
            return test;
        }
        static void Coloration(List<Utilisateur> list)
        {
            List<Utilisateur> coloration = new List<Utilisateur>();
            List<int> couleur = new List<int>();
            for (int i = 0; i < list.Count - 1; i++)
            {
                for (int j = 0; j < list.Count - i - 1; j++)
                {
                    if (list[j].Voisins.Count < list[j + 1].Voisins.Count)
                    {
                        Utilisateur temp = list[j];
                        list[j] = list[j + 1];
                        list[j + 1] = temp;
                    }
                }
            }
            int color = 0;
            int casecolor = 0;
            while (casecolor != list.Count)
            {
                color++;
                List<Utilisateur> coloré = new List<Utilisateur>();
                for (int i = 0; i < list.Count; i++)
                {
                    if (Contain(list[i].Num_util, coloration) == -1)
                    {
                        if (Contain(list[i].Num_util, coloré) == -1)
                        {
                            casecolor++;
                            coloration.Add(list[i]);
                            Console.WriteLine("L'utilisateur " + list[i].Prenom +" " + list[i].Nom +" est de la couleur " + color);
                            for (int o = 0; o < list[i].Voisins.Count; o++)
                            {
                                coloré.Add(Conver(list[i].Voisins[o], list));
                            }
                        }
                    }
                }
            }
            Console.WriteLine("Il faut " + color + " couleurs pour colorier le graphe des relations entre utilisateurs");
        }

        ///--------------------------------------------------------------------------------------------------------
        static string connexionString;

        static void Main(string[] args)
        {
            ///connexion à la base de donnée avec mot de passe 
            Console.Write("Entrez le mot de passe de la base de données MySQL (associé à votre localhost) : ");
            string mdep = Console.ReadLine();
            connexionString = $"SERVER=localhost;PORT=3306;DATABASE=food_delivery;UID=root;PASSWORD={mdep}";

            while (true) ///laisser affiché le menu tant que aucun 'case' n'est sélectionné 
            {
                Console.WriteLine("\n<===| Menu Principal |===>");
                Console.WriteLine("1. Interface Utilisateur");
                Console.WriteLine("2. Interface Administrateur");
                Console.WriteLine("3. Quitter");
                Console.Write("Choix: ");
                var choix = Console.ReadLine(); ///var pour pas que le code plante si une lettre est écrite par erreur
                switch (choix) ///séléction par l'utilisateur du menu choisi 
                {
                    case "1":
                        InterfaceUtilisateur();
                        break;
                    case "2":
                        DemandeMdpAdmin();
                        break;
                    case "3":
                        Console.WriteLine("Au revoir !");
                        return;
                    default:
                        Console.WriteLine("Choix invalide.");
                        break;
                }
            }
        }

        static void DemandeMdpAdmin()
        {
            Console.Write("Entrez le mot de passe admin : ");
            string mdpAdmin = Console.ReadLine();

            if (mdpAdmin == "1234")
            {
                InterfaceAdmin();
            }
            else
            {
                Console.WriteLine("Mot de passe incorrect. Retour au menu principal.");
            }
        }

        static void InterfaceUtilisateur()
        {
            while (true)
            {
                Console.WriteLine("\n<--- Interface Utilisateur --->");
                Console.WriteLine("1. Créer un utilisateur");
                Console.WriteLine("2. Afficher les plats disponibles");
                Console.WriteLine("3. Commander un plat");
                Console.WriteLine("4. Voir mes commandes");
                Console.WriteLine("5. Ajouter un plat");
                Console.WriteLine("6. (exo demandé) Voir le nombre de livraisons d'un cuisinier");
                Console.WriteLine("7. (exo demandé) Voir les commandes entre deux dates");
                Console.WriteLine("8. (exo demandé) Voir la moyenne des prix des commandes");
                Console.WriteLine("9. Retour au menu principal");
                Console.Write("Choix: ");
                var choix = Console.ReadLine();

                switch (choix)
                {
                    case "1": CreerUtilisateur(); break;
                    case "2": AfficherPlats(); break;
                    case "3": CommanderPlat(); break;
                    case "4": AfficherCommandes(); break;
                    case "5": AjouterPlat(); break;
                    case "6": AfficherLivCui(); break;
                    case "7": AfficherCommandesEntreDates(); break;
                    case "8": AfficherMoyennePrixCommandes(); break;
                    case "9": return;
                    default: Console.WriteLine("Choix invalide."); break;
                }
            }
        }

        static void InterfaceAdmin()
        {
            while (true)
            {
                Console.WriteLine("\n--- Interface Administrateur ---");
                Console.WriteLine("1. Créer un client ou un cuisinier");
                Console.WriteLine("2. Modifier un client ou un cuisinier");
                Console.WriteLine("3. Supprimer un client ou un cuisinier");
                Console.WriteLine("4. Créer une commande");
                Console.WriteLine("5. Modifier une commande");
                Console.WriteLine("6. Afficher une table de la base de données");
                Console.WriteLine("7. Retour au menu principal");
                Console.WriteLine("8. Afficher la coloration des utilisateurs");
                Console.Write("Choix: ");
                string choix = Console.ReadLine();

                switch (choix)
                {
                    case "1":
                        CreerClientOuCuisinier();
                        break;
                    case "2":
                        ModifierClientOuCuisinier();
                        break;
                    case "3":
                        SupprimerClientOuCuisinier();
                        break;
                    case "4":
                        CreerCommande();
                        break;
                    case "5":
                        ModifierCommande();
                        break;
                    case "6":
                        AfficherTable();
                        break;
                    case "7":
                        return; ///retourner au menu principal
                    case "8":
                        var utilisateurs = ChargerUtilisateurs();
                        var plats = ChargerPlats();
                        var commandes = ChargerCommandes(utilisateurs, plats);
                        Coloration(commandes);
                        break;
                    default:
                        Console.WriteLine("Choix non valide.");
                        break;
                }
            }
        }

        static void CreerClientOuCuisinier()
        {
            Console.WriteLine("\nCréation d'un client ou cuisinier");

            Console.Write("Nom: ");
            string nom = Console.ReadLine();
            Console.Write("Prénom: ");
            string prenom = Console.ReadLine();
            Console.Write("Rue: ");
            string rue = Console.ReadLine();
            Console.Write("Numéro de rue: ");
            int numeroRue = int.Parse(Console.ReadLine());
            Console.Write("Code postal: ");
            string codePostal = Console.ReadLine();
            Console.Write("Ville: ");
            string ville = Console.ReadLine();
            Console.Write("Téléphone: ");
            string tel = Console.ReadLine();
            Console.Write("Email: ");
            string email = Console.ReadLine();
            Console.Write("Rôle (0 = client, 1 = cuisinier, 2 = les deux): ");
            int role = int.Parse(Console.ReadLine());

            ///créer l'id de l'utilisateur en prenant 2 lettres prenom + numero rue + 2 lettres nom + 2 derniers chiffres code postal
            #region num_util
            string prefixPrenom = prenom.Length >= 2 ///verifies longueur afin de completer si nom ou prenom trop court 
                ? prenom.Substring(0, 2).ToUpper()
                : prenom.PadRight(2, 'X').ToUpper();

            string suffixNom = nom.Length >= 2
                ? nom.Substring(0, 2).ToUpper()
                : nom.PadRight(2, 'Y').ToUpper();

            string codePostalPart = codePostal.Length >= 2
                ? codePostal.Substring(codePostal.Length - 2)
                : "00";

            string num = $"{prefixPrenom}{numeroRue}{suffixNom}{codePostalPart}";
            #endregion  

            using var con = new MySqlConnection(connexionString);
            con.Open();

            ///verifier si l'email du compte créé n'existe pas deja dans la bdd
            var checkEmail = new MySqlCommand("SELECT COUNT(*) FROM utilisateur WHERE Email = @Email", con);
            checkEmail.Parameters.AddWithValue("@Email", email);
            if (Convert.ToInt32(checkEmail.ExecuteScalar()) > 0)
            {
                Console.WriteLine("Email déjà utilisé.");
                return;
            }

            ///insert les valeurs données par l'utilisateur dans la bdd
            var cmd = new MySqlCommand("INSERT INTO utilisateur (Num_util, Nom, Prenom, Rue, Numero_Rue, CodePostal, Ville, Tel, Email, Role) VALUES (@Num, @Nom, @Prenom, @Rue, @NumeroRue, @CodePostal, @Ville, @Tel, @Email, @Role)", con);
            cmd.Parameters.AddWithValue("@Num", num);
            cmd.Parameters.AddWithValue("@Nom", nom);
            cmd.Parameters.AddWithValue("@Prenom", prenom);
            cmd.Parameters.AddWithValue("@Rue", rue);
            cmd.Parameters.AddWithValue("@NumeroRue", numeroRue);
            cmd.Parameters.AddWithValue("@CodePostal", codePostal);
            cmd.Parameters.AddWithValue("@Ville", ville);
            cmd.Parameters.AddWithValue("@Tel", tel);
            cmd.Parameters.AddWithValue("@Email", email);
            cmd.Parameters.AddWithValue("@Role", role);

            ///ce try catch permet d'avertir l'utilisateur en cas d'erreur sql. si par exemple une valeure rentrée n'est pas du bon type
            try
            {
                cmd.ExecuteNonQuery();
                Console.WriteLine("Client ou cuisinier créé avec succès.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erreur lors de la création : {ex.Message}");
            }
        }

        static void ModifierClientOuCuisinier()
        {
            Console.WriteLine("\nModification d'un client ou cuisinier");
            Console.Write("Entrez le numéro d'utilisateur à modifier : ");
            string numUtil = Console.ReadLine();

            using var con = new MySqlConnection(connexionString);
            con.Open();
            ///chercher si dans la bdd le client existe a travers son id 
            var checkCmd = new MySqlCommand("SELECT COUNT(*) FROM utilisateur WHERE Num_util = @Num", con);
            checkCmd.Parameters.AddWithValue("@Num", numUtil);

            if (Convert.ToInt32(checkCmd.ExecuteScalar()) == 0)
            {
                Console.WriteLine("Utilisateur non trouvé.");
                return;
            }
            ///nouvelles valeurs de l'utilisateur
            Console.Write("Nouveau Nom: ");
            string nom = Console.ReadLine();
            Console.Write("Nouveau Prénom: ");
            string prenom = Console.ReadLine();
            Console.Write("Nouvelle Rue: ");
            string rue = Console.ReadLine();
            Console.Write("Nouveau Numéro de rue: ");
            int numeroRue = int.Parse(Console.ReadLine());
            Console.Write("Nouveau Code postal: ");
            string codePostal = Console.ReadLine();
            Console.Write("Nouvelle Ville: ");
            string ville = Console.ReadLine();
            Console.Write("Nouveau Téléphone: ");
            string tel = Console.ReadLine();
            Console.Write("Nouveau Email: ");
            string email = Console.ReadLine();
            Console.Write("Nouveau Rôle (0 = client, 1 = cuisinier, 2 = les deux): ");
            int role = int.Parse(Console.ReadLine());
            ///modification dans la bdd
            var cmd = new MySqlCommand(@"
        UPDATE utilisateur 
        SET Nom = @Nom, Prenom = @Prenom, Rue = @Rue, Numero_Rue = @NumeroRue,
            CodePostal = @CodePostal, Ville = @Ville, Tel = @Tel, Email = @Email, Role = @Role
        WHERE Num_util = @Num", con);

            cmd.Parameters.AddWithValue("@Nom", nom);
            cmd.Parameters.AddWithValue("@Prenom", prenom);
            cmd.Parameters.AddWithValue("@Rue", rue);
            cmd.Parameters.AddWithValue("@NumeroRue", numeroRue);
            cmd.Parameters.AddWithValue("@CodePostal", codePostal);
            cmd.Parameters.AddWithValue("@Ville", ville);
            cmd.Parameters.AddWithValue("@Tel", tel);
            cmd.Parameters.AddWithValue("@Email", email);
            cmd.Parameters.AddWithValue("@Role", role);
            cmd.Parameters.AddWithValue("@Num", numUtil);

            try
            {
                cmd.ExecuteNonQuery();
                Console.WriteLine("Utilisateur modifié avec succès.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erreur lors de la modification : {ex.Message}");
            }
        }

        static void SupprimerClientOuCuisinier()
        {
            ///meme fonctionnement que la fonction précédente  
            Console.WriteLine("\nSuppression d'un client ou cuisinier");

            Console.Write("Entrez le numéro d'utilisateur à supprimer : ");
            string numUtil = Console.ReadLine();

            using var con = new MySqlConnection(connexionString);
            con.Open();

            var checkCmd = new MySqlCommand("SELECT COUNT(*) FROM utilisateur WHERE Num_util = @Num", con);
            checkCmd.Parameters.AddWithValue("@Num", numUtil);

            if (Convert.ToInt32(checkCmd.ExecuteScalar()) == 0)
            {
                Console.WriteLine("Utilisateur non trouvé.");
                return;
            }

            Console.Write("Êtes-vous sûr de vouloir supprimer cet utilisateur ? (Y/N) : ");
            string confirmation = Console.ReadLine();
            if (confirmation.ToUpper() != "Y")
            {
                Console.WriteLine("Suppression annulée.");
                return;
            }

            var cmd = new MySqlCommand("DELETE FROM utilisateur WHERE Num_util = @Num", con);
            cmd.Parameters.AddWithValue("@Num", numUtil);

            try
            {
                cmd.ExecuteNonQuery();
                Console.WriteLine("Utilisateur supprimé avec succès.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erreur lors de la suppression : {ex.Message}");
            }
        }

        static void CreerCommande()
        {
            Console.WriteLine("\nCréation d'une commande");

            Console.Write("Numéro du client : ");
            string numClient = Console.ReadLine();

            Console.Write("ID du plat : ");
            string idPlat = Console.ReadLine();

            Console.Write("Quantité : ");
            int quantite = int.Parse(Console.ReadLine());

            using var con = new MySqlConnection(connexionString);
            con.Open();

            ///vérifier que client et plat existent
            var checkClient = new MySqlCommand("SELECT COUNT(*) FROM utilisateur WHERE Num_util = @Num", con);
            checkClient.Parameters.AddWithValue("@Num", numClient);
            if (Convert.ToInt32(checkClient.ExecuteScalar()) == 0)
            {
                Console.WriteLine("Client non trouvé.");
                return;
            }

            var checkPlat = new MySqlCommand("SELECT Prix FROM Plat WHERE id_plat = @id", con);
            checkPlat.Parameters.AddWithValue("@id", idPlat);
            object prixResult = checkPlat.ExecuteScalar();
            if (prixResult == null)
            {
                Console.WriteLine("Plat non trouvé.");
                return;
            }
            decimal prixUnitaire = Convert.ToDecimal(prixResult);

            decimal prixTotal = prixUnitaire * quantite;

            var lastCmd = new MySqlCommand("SELECT Numero_Commande FROM Commande ORDER BY Numero_Commande DESC LIMIT 1", con);
            var lastCmdResult = lastCmd.ExecuteScalar();
            int newId = 1;
            if (lastCmdResult != null && lastCmdResult.ToString().Length > 1)
            {
                string lastNum = lastCmdResult.ToString().Substring(1);
                if (int.TryParse(lastNum, out int lastInt))
                {
                    newId = lastInt + 1;
                }
            }
            string idCmd = $"C{newId:D3}";

            var cmd = new MySqlCommand("INSERT INTO Commande (Numero_Commande, id_plat, Prix, Quantite, date_commande, Num_client) VALUES (@numCmd, @idPlat, @prix, @quantite, NOW(), @numClient)", con);
            cmd.Parameters.AddWithValue("@numCmd", idCmd);
            cmd.Parameters.AddWithValue("@idPlat", idPlat);
            cmd.Parameters.AddWithValue("@prix", prixTotal);
            cmd.Parameters.AddWithValue("@quantite", quantite);
            cmd.Parameters.AddWithValue("@numClient", numClient);

            try
            {
                cmd.ExecuteNonQuery();
                Console.WriteLine($"Commande {idCmd} créée avec succès.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erreur : {ex.Message}");
            }
        }

        static void ModifierCommande()
        {
            Console.WriteLine("\nModification d'une commande");

            Console.Write("Entrez le numéro de commande à modifier : ");
            string numCmd = Console.ReadLine();

            using var con = new MySqlConnection(connexionString);
            con.Open();

            var checkCmd = new MySqlCommand("SELECT COUNT(*) FROM Commande WHERE Numero_Commande = @Num", con);
            checkCmd.Parameters.AddWithValue("@Num", numCmd);

            if (Convert.ToInt32(checkCmd.ExecuteScalar()) == 0)
            {
                Console.WriteLine("Commande non trouvée.");
                return;
            }

            Console.Write("Nouvelle quantité : ");
            int nouvelleQuantite = int.Parse(Console.ReadLine());

            var getPrix = new MySqlCommand("SELECT p.Prix FROM Commande c JOIN Plat p ON c.id_plat = p.id_plat WHERE c.Numero_Commande = @Num", con);
            getPrix.Parameters.AddWithValue("@Num", numCmd);
            decimal prixUnitaire = Convert.ToDecimal(getPrix.ExecuteScalar());
            decimal nouveauPrixTotal = prixUnitaire * nouvelleQuantite;

            var updateCmd = new MySqlCommand("UPDATE Commande SET Quantite = @quantite, Prix = @prix WHERE Numero_Commande = @Num", con);
            updateCmd.Parameters.AddWithValue("@quantite", nouvelleQuantite);
            updateCmd.Parameters.AddWithValue("@prix", nouveauPrixTotal);
            updateCmd.Parameters.AddWithValue("@Num", numCmd);

            try
            {
                updateCmd.ExecuteNonQuery();
                Console.WriteLine("Commande modifiée avec succès.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erreur lors de la modification : {ex.Message}");
            }
        }

        static void AfficherTable()
        {
            Console.Write("\nEntrez le nom de la table à afficher (utilisateur / plat / commande / livraison / trajet) : ");
            string table = Console.ReadLine();

            using var con = new MySqlConnection(connexionString);
            try
            {
                con.Open();
                var cmd = new MySqlCommand($"SELECT * FROM {table}", con);
                using var reader = cmd.ExecuteReader();

                Console.WriteLine($"\nContenu de la table {table} :");
                while (reader.Read())
                {
                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        Console.Write($"{reader.GetName(i)}: {reader.GetValue(i)} | ");
                    }
                    Console.WriteLine();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erreur lors de l'affichage : {ex.Message}");
            }
        }

        static void CreerUtilisateur()
        {
            Console.Write("Nom: ");
            string nom = Console.ReadLine();
            Console.Write("Prénom: ");
            string prenom = Console.ReadLine();
            Console.Write("Rue: ");
            string rue = Console.ReadLine();
            Console.Write("Numéro de rue: ");
            int numeroRue = int.Parse(Console.ReadLine());
            Console.Write("Code postal: ");
            string codePostal = Console.ReadLine();
            Console.Write("Ville: ");
            string ville = Console.ReadLine();
            Console.Write("Téléphone: ");
            string tel = Console.ReadLine();
            Console.Write("Email: ");
            string email = Console.ReadLine();
            Console.Write("Rôle (0 = client, 1 = cuisinier, 2 = les deux): ");
            int role = int.Parse(Console.ReadLine());

            string prefixPrenom = prenom.Length >= 2
                ? prenom.Substring(0, 2).ToUpper()
                : prenom.PadRight(2, 'X').ToUpper();

            string suffixNom = nom.Length >= 2
                ? nom.Substring(0, 2).ToUpper()
                : nom.PadRight(2, 'Y').ToUpper();

            string codePostalPart = codePostal.Length >= 2
                ? codePostal.Substring(codePostal.Length - 2)
                : "00";

            string num = $"{prefixPrenom}{numeroRue}{suffixNom}{codePostalPart}";


            using var con = new MySqlConnection(connexionString);
            con.Open();

            var checkEmail = new MySqlCommand("SELECT COUNT(*) FROM utilisateur WHERE Email = @Email", con);
            checkEmail.Parameters.AddWithValue("@Email", email);
            if (Convert.ToInt32(checkEmail.ExecuteScalar()) > 0)
            {
                Console.WriteLine("Email déjà utilisé.");
                return;
            }

            var cmd = new MySqlCommand("INSERT INTO utilisateur (Num_util, Nom, Prenom, Rue, Numero_Rue, CodePostal, Ville, Tel, Email, Role) VALUES (@Num, @Nom, @Prenom, @Rue, @NumeroRue, @CodePostal, @Ville, @Tel, @Email, @Role)", con);
            cmd.Parameters.AddWithValue("@Num", num);
            cmd.Parameters.AddWithValue("@Nom", nom);
            cmd.Parameters.AddWithValue("@Prenom", prenom);
            cmd.Parameters.AddWithValue("@Rue", rue);
            cmd.Parameters.AddWithValue("@NumeroRue", numeroRue);
            cmd.Parameters.AddWithValue("@CodePostal", codePostal);
            cmd.Parameters.AddWithValue("@Ville", ville);
            cmd.Parameters.AddWithValue("@Tel", tel);
            cmd.Parameters.AddWithValue("@Email", email);
            cmd.Parameters.AddWithValue("@Role", role);

            try
            {
                cmd.ExecuteNonQuery();
                Console.WriteLine("Utilisateur créé avec succès.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erreur lors de la création : {ex.Message}");
            }
        }

        static void AfficherPlats()
        {
            using var con = new MySqlConnection(connexionString);
            con.Open();

            var cmd = new MySqlCommand("SELECT id_plat, Nom_Plat, Prix FROM Plat", con);
            using var reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                Console.WriteLine($"{reader["id_plat"]} - {reader["Nom_Plat"]} | Prix: {reader["Prix"]}€");
            }
        }

        static void AjouterPlat()
        {
            Console.Write("Nom du plat: ");
            string nom = Console.ReadLine();
            Console.Write("Type: ");
            string type = Console.ReadLine();
            Console.Write("Date fabrication (yyyy-mm-dd): ");
            DateTime fabrication = DateTime.Parse(Console.ReadLine());
            Console.Write("Date péremption (yyyy-mm-dd): ");
            DateTime peremption = DateTime.Parse(Console.ReadLine());
            Console.Write("Régime: ");
            string regime = Console.ReadLine();
            Console.Write("Nature: ");
            string nature = Console.ReadLine();
            Console.Write("Prix (€): ");
            decimal prix = decimal.Parse(Console.ReadLine());
            Console.Write("Numéro cuisinier: ");
            string numCuisinier = Console.ReadLine();

            using var con = new MySqlConnection(connexionString);
            con.Open();

            var cmdId = new MySqlCommand("SELECT id_plat FROM Plat ORDER BY id_plat DESC LIMIT 1", con);
            var lastId = cmdId.ExecuteScalar();
            int newNum = 1;
            if (lastId != null)
            {
                string idStr = lastId.ToString().Substring(1);
                if (int.TryParse(idStr, out int lastInt)) newNum = lastInt + 1;
            }
            string newId = "P" + newNum.ToString("D3");

            var cmd = new MySqlCommand("INSERT INTO Plat (id_plat, Nom_Plat, type, date_fabrication, date_peremption, regime, Nature, Prix, Num_cuisinier) VALUES (@id, @nom, @type, @fab, @per, @regime, @nature, @prix, @cuisinier)", con);
            cmd.Parameters.AddWithValue("@id", newId);
            cmd.Parameters.AddWithValue("@nom", nom);
            cmd.Parameters.AddWithValue("@type", type);
            cmd.Parameters.AddWithValue("@fab", fabrication);
            cmd.Parameters.AddWithValue("@per", peremption);
            cmd.Parameters.AddWithValue("@regime", regime);
            cmd.Parameters.AddWithValue("@nature", nature);
            cmd.Parameters.AddWithValue("@prix", prix);
            cmd.Parameters.AddWithValue("@cuisinier", numCuisinier);

            try
            {
                cmd.ExecuteNonQuery();
                Console.WriteLine("Plat ajouté avec succès.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erreur lors de l'ajout du plat : {ex.Message}");
            }
        }

        static void AfficherCommandes()
        {
            Console.Write("Numéro utilisateur: ");
            string numClient = Console.ReadLine();

            using var con = new MySqlConnection(connexionString);
            con.Open();

            var cmd = new MySqlCommand("SELECT c.Numero_Commande, p.Nom_Plat, c.Quantite, c.Prix, c.date_commande FROM Commande c JOIN Plat p ON c.id_plat = p.id_plat WHERE c.Num_client = @Num", con);
            cmd.Parameters.AddWithValue("@Num", numClient);

            using var reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                Console.WriteLine($"Commande {reader["Numero_Commande"]}: {reader["Nom_Plat"]} x{reader["Quantite"]} - Total: {reader["Prix"]}€ - Date: {reader["date_commande"]}");
            }
        }

        static void CommanderPlat()
        {
            Console.Write("Numéro utilisateur: ");
            string numClient = Console.ReadLine();

            Console.Write("ID du plat: ");
            string idPlat = Console.ReadLine();

            using var con = new MySqlConnection(connexionString);
            con.Open();

            var prixCmd = new MySqlCommand("SELECT Prix FROM Plat WHERE id_plat = @id", con);
            prixCmd.Parameters.AddWithValue("@id", idPlat);
            var prixUnitaire = Convert.ToDecimal(prixCmd.ExecuteScalar());

            Console.WriteLine($"Prix unitaire du plat : {prixUnitaire}€");
            Console.Write("Quantité: ");
            int quantite = int.Parse(Console.ReadLine());

            decimal prixTotal = prixUnitaire * quantite;
            Console.WriteLine($"Montant total à payer : {prixTotal}€");

            Console.Write("Souhaitez-vous confirmer la commande ? (Y/N) : ");
            string confirmation = Console.ReadLine();
            if (confirmation.Trim().ToUpper() != "Y")
            {
                Console.WriteLine("❌ Commande annulée.");
                return;
            }

            var lastCmd = new MySqlCommand("SELECT Numero_Commande FROM Commande ORDER BY Numero_Commande DESC LIMIT 1", con);
            var lastCmdResult = lastCmd.ExecuteScalar();
            int newId = 1;
            if (lastCmdResult != null && lastCmdResult.ToString().Length > 1)
            {
                string lastNum = lastCmdResult.ToString().Substring(1);
                if (int.TryParse(lastNum, out int lastInt))
                {
                    newId = lastInt + 1;
                }
            }
            string idCmd = $"C{newId:D3}";

            var cmd = new MySqlCommand("INSERT INTO Commande (Numero_Commande, id_plat, Prix, Quantite, date_commande, Num_client) VALUES (@numCmd, @idPlat, @prix, @quantite, NOW(), @numClient)", con);
            cmd.Parameters.AddWithValue("@numCmd", idCmd);
            cmd.Parameters.AddWithValue("@idPlat", idPlat);
            cmd.Parameters.AddWithValue("@prix", prixTotal);
            cmd.Parameters.AddWithValue("@quantite", quantite);
            cmd.Parameters.AddWithValue("@numClient", numClient);

            try
            {
                cmd.ExecuteNonQuery();
                Console.WriteLine($"✅ Commande {idCmd} passée avec succès.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Erreur : {ex.Message}");
            }
        }

        static void AfficherLivCui()
        {
            Console.Write("Entrez l'ID du cuisinier : ");
            string numCuisinier = Console.ReadLine();

            using var con = new MySqlConnection(connexionString);
            con.Open();

            var checkRoleCmd = new MySqlCommand("SELECT Role FROM utilisateur WHERE Num_util = @id", con);
            checkRoleCmd.Parameters.AddWithValue("@id", numCuisinier);
            var roleResult = checkRoleCmd.ExecuteScalar();

            if (roleResult == null)
            {
                Console.WriteLine("Utilisateur introuvable.");
                return;
            }

            int role = Convert.ToInt32(roleResult);
            if (role == 0)
            {
                Console.WriteLine("Cet utilisateur est un client, pas un cuisinier.");
                return;
            }

            var cmd = new MySqlCommand(@"
                SELECT COUNT(l.id_livraison) AS NbLivraisons
                FROM Livraison l
                JOIN Trajet t ON l.id_trajet = t.id_trajet
                WHERE t.Num_traj = @numCuisinier AND l.statut = 'Livrée';", con);

            cmd.Parameters.AddWithValue("@numCuisinier", numCuisinier);
            var result = cmd.ExecuteScalar();

            Console.WriteLine($"\nNombre de livraisons effectuées : {result}");
        }

        static void AfficherCommandesEntreDates()
        {
            Console.Write("Entrez la date de début (YYYY-MM-DD) : ");
            string dateDebut = Console.ReadLine();
            Console.Write("Entrez la date de fin (YYYY-MM-DD) : ");
            string dateFin = Console.ReadLine();

            using var con = new MySqlConnection(connexionString);
            con.Open();

            var cmd = new MySqlCommand(@"
                SELECT c.Numero_Commande, u.Nom, u.Prenom, p.Nom_Plat, c.Quantite, c.Prix, c.date_commande
                FROM Commande c
                JOIN utilisateur u ON c.Num_client = u.Num_util
                JOIN Plat p ON c.id_plat = p.id_plat
                WHERE c.date_commande BETWEEN @dateDebut AND @dateFin
                ORDER BY c.date_commande ASC;", con);

            cmd.Parameters.AddWithValue("@dateDebut", dateDebut);
            cmd.Parameters.AddWithValue("@dateFin", dateFin);

            using var reader = cmd.ExecuteReader();
            Console.WriteLine("\nCommandes passées entre ces dates :\n");
            while (reader.Read())
            {
                Console.WriteLine($"Commande {reader["Numero_Commande"]} - Client: {reader["Nom"]} {reader["Prenom"]}, Plat: {reader["Nom_Plat"]}, Quantité: {reader["Quantite"]}, Total: {reader["Prix"]}€, Date: {Convert.ToDateTime(reader["date_commande"]).ToShortDateString()}");
            }
        }

        static void AfficherMoyennePrixCommandes()
        {
            using var con = new MySqlConnection(connexionString);
            con.Open();

            var cmd = new MySqlCommand("SELECT AVG(Prix) FROM Commande", con);
            var result = cmd.ExecuteScalar();

            if (result != DBNull.Value)
            {
                decimal moyenne = Convert.ToDecimal(result);
                Console.WriteLine($"\nMoyenne des prix des commandes : {moyenne:F2}€");
            }
            else
            {
                Console.WriteLine("\nAucune commande trouvée pour calculer la moyenne.");
            }
        }
    }
}


